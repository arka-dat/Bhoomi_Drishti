import streamlit as st
import pandas as pd
import numpy as np
import joblib
import shap
import plotly.graph_objects as go
import plotly.express as px

# -----------------------------
# Page Settings
# -----------------------------

st.set_page_config(
    page_title="Land Delay Prediction",
    page_icon="🏗️",
    layout="wide"
)

st.title("🏗️ Land Acquisition Delay Prediction")

st.write(
    "Predict whether a land acquisition project is likely to be delayed."
)

# -----------------------------
# Load Model
# -----------------------------

model = joblib.load("knn_model.pkl")
le = joblib.load("label_encoder.pkl")

df = pd.read_csv("Land_cleaned.csv")

features = [
    "District_Count",
    "Total_Affected_Parties_Count",
    "Total_Villages_Count",
    "Land_Required_Acres",
    "Sanction_Amount",
    "Land_To_Be_Acquired_Acres"
]

# -----------------------------
# User Input
# -----------------------------

st.header("📋 Project Information")

col1, col2 = st.columns(2)

with col1:

    district_count = st.number_input(
        "District Count",
        min_value=0.0,
        value=1.0
    )

    affected_parties = st.number_input(
        "Total Affected Parties Count",
        min_value=0.0,
        value=10.0
    )

    villages = st.number_input(
        "Total Villages Count",
        min_value=0.0,
        value=5.0
    )

with col2:

    land_required = st.number_input(
        "Land Required (Acres)",
        min_value=0.0,
        value=10.0
    )

    sanction_amount = st.number_input(
        "Sanction Amount",
        min_value=0.0,
        value=1000000.0
    )

    land_acquired = st.number_input(
        "Land To Be Acquired (Acres)",
        min_value=0.0,
        value=10.0
    )

# -----------------------------
# Input Data
# -----------------------------

input_data = {
    "District_Count": district_count,
    "Total_Affected_Parties_Count": affected_parties,
    "Total_Villages_Count": villages,
    "Land_Required_Acres": land_required,
    "Sanction_Amount": sanction_amount,
    "Land_To_Be_Acquired_Acres": land_acquired
}

input_df = pd.DataFrame([input_data])

# -----------------------------
# Prediction
# -----------------------------

if st.button("🔍 Predict Delay", use_container_width=True):

    prediction = model.predict(input_df)

    prediction_label = le.inverse_transform(prediction)[0]

    probabilities = model.predict_proba(input_df)[0]

    yes_index = list(le.classes_).index("yes")

    delay_probability = probabilities[yes_index] * 100

    # -------------------------
    # Result
    # -------------------------

    st.header("📊 Prediction Result")

    if prediction_label == "yes":

        st.error("⚠️ Project is likely to be DELAYED")

    else:

        st.success("✅ Project is likely to NOT be delayed")

    st.metric(
        "Delay Probability",
        f"{delay_probability:.1f}%"
    )

    # -------------------------
    # Risk Category
    # -------------------------

    if delay_probability <= 30:

        risk = "Low Delay Risk"

    elif delay_probability <= 70:

        risk = "Medium Delay Risk"

    else:

        risk = "High Delay Risk"

    st.info(f"Risk Level: **{risk}**")

    # -------------------------
    # Gauge Chart
    # -------------------------

    fig = go.Figure(
        go.Indicator(
            mode="gauge+number",
            value=delay_probability,
            title={"text": "Delay Probability"},
            gauge={
                "axis": {
                    "range": [0, 100]
                },
                "threshold": {
                    "line": {
                        "width": 4
                    },
                    "value": delay_probability
                }
            }
        )
    )

    fig.update_layout(
        height=350
    )

    st.plotly_chart(
        fig,
        use_container_width=True
    )

    # -----------------------------
    # SHAP Explanation
    # -----------------------------

    st.header("🧠 Why is this project likely to be delayed?")

    background = shap.sample(
        df[features],
        50,
        random_state=42
    )

    # Wrapper function
    def predict_proba(data):

        data = pd.DataFrame(
            data,
            columns=features
        )

        return model.predict_proba(data)

    # SHAP Explainer
    explainer = shap.KernelExplainer(
        predict_proba,
        background
    )

    shap_values = explainer.shap_values(
        input_df,
        nsamples=100
    )

    # Get SHAP values for "yes"
    if isinstance(shap_values, list):

        values = shap_values[yes_index][0]

    else:

        shap_values = np.asarray(shap_values)

        if shap_values.ndim == 3:

            values = shap_values[0, :, yes_index]

        else:

            values = shap_values[0]

    # -----------------------------
    # SHAP DataFrame
    # -----------------------------

    shap_df = pd.DataFrame({
        "Feature": features,
        "SHAP Value": values
    })

    shap_df["Impact"] = np.where(
        shap_df["SHAP Value"] > 0,
        "Increases Delay Risk",
        "Decreases Delay Risk"
    )

    shap_df = shap_df.sort_values(
        "SHAP Value"
    )

    # -----------------------------
    # SHAP Plot
    # -----------------------------

    fig_shap = px.bar(
        shap_df,
        x="SHAP Value",
        y="Feature",
        color="Impact",
        orientation="h",
        title="Factors Affecting Delay Prediction"
    )

    fig_shap.update_layout(
        height=450
    )

    st.plotly_chart(
        fig_shap,
        use_container_width=True
    )

    # -----------------------------
    # Explanation
    # -----------------------------

    st.subheader("🔎 Main Factors")

    positive = shap_df[
        shap_df["SHAP Value"] > 0
    ].sort_values(
        "SHAP Value",
        ascending=False
    )

    if len(positive) > 0:

        for _, row in positive.iterrows():

            st.write(
                f"🔴 **{row['Feature']}** "
                f"is increasing the model's predicted delay risk."
            )

    else:

        st.write(
            "🟢 The selected factors are not strongly "
            "increasing the predicted delay risk."
        )